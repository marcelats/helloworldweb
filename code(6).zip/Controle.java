package com.javasim.teste.basic;
import org.javasim.RestartException;
import org.javasim.Simulation;
import org.javasim.SimulationException;
import org.javasim.SimulationProcess;

public class Controle extends SimulationProcess
{

	public static server server = null;
	public static Fila filaDoserver = new Fila();


    public static double tempoRespostaTotal = 0.0;
    public static long totalClientes = 0;
    public static long clientesProcessados = 0;
    public static double totalServico = 0;


    public Controle()
    {
        
    }

    public void run ()
    {
        try
        {
			Chegadas chegadas = new Chegadas(10);
			Controle.server = new server(2);
            chegadas.activate();

            Simulation.start();

			hold(100000);

            System.out.println("Tempo total = "+currentTime());
            System.out.println("Total de clientes presentes no sistema = " + totalClientes);
            System.out.println("Total de clientes processados = " + clientesProcessados);
            System.out.println("Tempo de resposta total = " + tempoRespostaTotal);
            System.out.println("Tempo médio de resposta = "
                + (tempoRespostaTotal / clientesProcessados));
            
			System.out.println("Utilização do server = " + Controle.server.tempoDeServico);
			System.out.println("Comprimento médio de filaserver = "+ (Controle.filaDoserver.clientesEmFila / Controle.filaDoserver.checkFila));

            Simulation.stop();

            chegadas.terminate();
			Controle.server.terminate();

            SimulationProcess.mainResume();
        }
        catch (SimulationException e)
        {
        }
        catch (RestartException e)
        {
        }
    }
    public void await ()
    {
        this.resumeProcess();
        SimulationProcess.mainSuspend();
    }

}
