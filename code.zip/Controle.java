package com.javasim.teste.basic;
import org.javasim.RestartException;
import org.javasim.Simulation;
import org.javasim.SimulationException;
import org.javasim.SimulationProcess;

public class Controle extends SimulationProcess
{

	  public static CPU0 cpu0 = null;
	  public static Fila filaDoCPU0 = new Fila();

	  public static CPU1 cpu1 = null;
	  public static Fila filaDoCPU1 = new Fila();


    public static double tempoRespostaTotal = 0.0;
    public static long totalClientes = 0;
    public static long clientesProcessados = 0;
    public static double totalServico = 0;


    public Controle()
    {
        System.out.println("controle");
    }

    public void run ()
    {
        System.out.println("run");
        try
        {
            System.out.println("try");
			      Chegadas chegadas = new Chegadas(10);
			      Controle.cpu0 = new CPU0(5);
			      Controle.cpu1 = new CPU1(2);
            chegadas.activate();

            Simulation.start();

			      hold(100000);

            System.out.println("Tempo total = "+currentTime());
            System.out.println("Total de clientes presentes no sistema = " + totalClientes);
            System.out.println("Total de clientes processados = " + clientesProcessados);
            System.out.println("Tempo de resposta total = " + tempoRespostaTotal);
            System.out.println("Tempo médio de resposta = "
                + (tempoRespostaTotal / clientesProcessados));
            
			      System.out.println("Utilização do CPU0 = " + Controle.cpu0.tempoDeServico);
			      System.out.println("Comprimento médio de filaCPU0 = "+ (Controle.filaDoCPU0.clientesEmFila / Controle.filaDoCPU0.checkFila));
			      System.out.println("Utilização do CPU1 = " + Controle.cpu1.tempoDeServico);
			      System.out.println("Comprimento médio de filaCPU1 = "+ (Controle.filaDoCPU1.clientesEmFila / Controle.filaDoCPU1.checkFila));

            Simulation.stop();

            chegadas.terminate();
            Controle.cpu0.terminate();
            Controle.cpu1.terminate();

            SimulationProcess.mainResume();
        }
        catch (SimulationException e)
        {
        }
        catch (RestartException e)
        {
        }
    }
    public void await ()
    {
        this.resumeProcess();
        SimulationProcess.mainSuspend();
    }
}
